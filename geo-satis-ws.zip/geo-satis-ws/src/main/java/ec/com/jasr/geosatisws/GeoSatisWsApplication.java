package ec.com.jasr.geosatisws;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GeoSatisWsApplication {

	public static void main(String[] args) {
		SpringApplication.run(GeoSatisWsApplication.class, args);
	}

}
